"""
VÉLØ Oracle - Prediction Chain
Complete prediction pipeline with all intelligence layers
"""

import logging
import time
from typing import Any

logger = logging.getLogger(__name__)


async def run_prediction_chain(race: dict[str, Any], runners: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Execute complete prediction chain

    Pipeline:
    1. Load models
    2. Extract features
    3. SQPE scoring
    4. Trainer Intent Engine
    5. Longshot detection
    6. Overlay detection
    7. Risk layer
    8. Narrative analysis
    9. Market manipulation check
    10. Pace analysis
    11. Unify output

    Returns:
        Unified prediction output with all signals
    """
    start_time = time.time()

    try:
        # Step 1: Load models
        models = await load_models()

        # Step 2: Extract features for all runners
        features_list = await extract_features_batch(runners, race)

        # Step 3-6: Run model predictions
        predictions = []
        for runner, features in zip(runners, features_list, strict=False):
            pred = await run_model_predictions(runner, features, models, race=race)
            predictions.append(pred)

        # Step 7: Apply risk layer
        predictions = await apply_risk_layer(predictions)

        # Step 8: Narrative analysis
        narrative = await analyze_narrative(race, runners)

        # Step 9: Market manipulation check
        manipulation = await check_manipulation(race, runners)

        # Step 10: Pace analysis
        pace = await analyze_pace(runners, race)

        # Step 11: Unify output
        result = unify_output(predictions, narrative, manipulation, pace)

        execution_time = (time.time() - start_time) * 1000

        result.update(
            {
                "status": "success",
                "execution_duration_ms": round(execution_time, 2),
                "chain": "prediction",
                "runners_analyzed": len(runners),
            }
        )

        logger.info(f"✅ Prediction chain complete: {execution_time:.2f}ms")

        return result

    except Exception as e:
        execution_time = (time.time() - start_time) * 1000
        logger.error(f"❌ Prediction chain failed: {e}")

        return {
            "status": "error",
            "error": str(e),
            "execution_duration_ms": round(execution_time, 2),
            "chain": "prediction",
        }


async def load_models() -> dict[str, Any]:
    """Load all required models"""
    from app.services.model_manager import get_model_manager

    model_manager = get_model_manager()

    return {
        "sqpe": model_manager.get_model("sqpe"),
        "tie": model_manager.get_model("trainer_intent"),
        "longshot": model_manager.get_model("longshot"),
        "overlay": model_manager.get_model("benter_overlay"),
    }


async def extract_features_batch(runners: list[dict], race: dict) -> list[dict]:
    """Extract v16 base features + v17 doctrine features for all runners."""
    from app.services.feature_engineering import extract_features
    from app.services.v17_feature_extractor import V17FeatureExtractor

    extractor = V17FeatureExtractor()
    features_list = []
    for runner in runners:
        # v16 base features (20 legacy features — used by downstream intelligence layers)
        features = extract_features(runner, race, historical=None)

        # v17 doctrine features — fetched from Racing API horse form
        horse_id = runner.get("horse_id") or runner.get("id", "")
        race_context = {
            "course": race.get("course", ""),
            "going": race.get("going", "Good"),
            "dist_f": race.get("distance_f") or race.get("dist_f"),
            "or_num": runner.get("or") or runner.get("official_rating"),
            "sp_dec": runner.get("sp_dec") or runner.get("odds"),
            "jockey": runner.get("jockey", ""),
            "is_fav": runner.get("is_fav", 0),
        }
        if horse_id:
            doctrine = extractor.extract(horse_id, race_context)
            features.update(doctrine)

        features_list.append(features)

    return features_list


async def run_model_predictions(
    runner: dict,
    features: dict,
    models: dict,
    race: dict = None,
) -> dict[str, Any]:
    """Run all model predictions for a runner"""
    from app.services.model_manager import get_model_manager

    mm = get_model_manager()

    # SQPE v17 — pass raw runner+race so model_manager builds the correct 37-feature vector
    sqpe_score = mm.predict_sqpe(features, runner=runner, race=race or {})

    # Trainer Intent
    tie_signal = mm.predict_trainer_intent(features)

    # Longshot
    odds = runner.get("odds", 5.0)
    longshot_score = mm.predict_longshot(features, odds)

    # Final probability (weighted combination)
    final_prob = (sqpe_score * 0.5) + (tie_signal * 0.3) + (longshot_score * 0.2)

    # Overlay detection
    overlay = mm.detect_overlay(final_prob, odds)

    return {
        "runner_id": runner.get("runner_id"),
        "runner_name": runner.get("horse"),
        "sqpe_score": sqpe_score,
        "tie_signal": tie_signal,
        "longshot_score": longshot_score,
        "final_probability": final_prob,
        "market_odds": odds,
        "overlay": overlay,
        "features": features,
    }


async def apply_risk_layer(predictions: list[dict]) -> list[dict]:
    """Apply risk layer to all predictions"""
    from app.services.risk_layer import calculate_risk_metrics

    for pred in predictions:
        risk_metrics = calculate_risk_metrics(
            model_prob=pred["final_probability"], market_odds=pred["market_odds"], confidence=0.75
        )

        pred.update(
            {
                "edge": risk_metrics["edge"],
                "risk_band": risk_metrics["risk_band"],
                "kelly_stake": risk_metrics["kelly_stake"],
                "expected_value": risk_metrics["expected_value"],
            }
        )

    return predictions


async def analyze_narrative(race: dict, runners: list[dict]) -> dict[str, Any]:
    """Run narrative analysis"""
    from app.intelligence.narrative_disruption import detect_market_story

    race_with_runners = race.copy()
    race_with_runners["runners"] = runners

    narrative = detect_market_story(race_with_runners)

    return {
        "narrative_type": narrative.get("story"),
        "disruption_risk": narrative.get("disruption_risk", 0.0),
        "confidence": narrative.get("confidence", 0.0),
    }


async def check_manipulation(race: dict, runners: list[dict]) -> dict[str, Any]:
    """Check for market manipulation"""
    # Stub: Would use real odds history
    return {"manipulation_detected": False, "risk_score": 0.0, "confidence": 0.0}


async def analyze_pace(runners: list[dict], race: dict) -> dict[str, Any]:
    """Run pace analysis"""
    from app.intelligence.pace_map import create_pace_map

    pace_map = create_pace_map(runners)

    return {
        "pace_scenario": pace_map.get("pace_scenario", {}).get("type"),
        "pace_pressure": pace_map.get("pace_pressure", 0.0),
        "advantaged_count": len(pace_map.get("advantaged_runners", [])),
    }


def unify_output(predictions: list[dict], narrative: dict, manipulation: dict, pace: dict) -> dict[str, Any]:
    """Unify all chain outputs"""

    # Find top pick
    top_pick = max(predictions, key=lambda p: p["final_probability"])

    # Count overlays
    overlay_count = sum(1 for p in predictions if p.get("overlay", {}).get("is_overlay"))

    return {
        "predictions": predictions,
        "top_pick": {
            "runner": top_pick["runner_name"],
            "probability": top_pick["final_probability"],
            "edge": top_pick.get("edge", 0.0),
            "risk_band": top_pick.get("risk_band", "NO_BET"),
        },
        "signals": {"narrative": narrative, "manipulation": manipulation, "pace": pace},
        "overlay_count": overlay_count,
        "confidence_scores": {
            "narrative": narrative.get("confidence", 0.0),
            "manipulation": manipulation.get("confidence", 0.0),
            "pace": 0.75,  # Stub
        },
    }
