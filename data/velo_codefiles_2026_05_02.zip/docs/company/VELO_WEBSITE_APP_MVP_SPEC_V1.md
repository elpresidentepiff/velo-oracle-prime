# VELO Website / App MVP Specification V1

**Date:** 2026-04-29  
**Status:** Spec only - ETCSLV aligned  
**Positioning:** Race intelligence and decision support, not gambling tips

---

## Core Principle

VELO's product is the evidence loop, not the pick itself.

Every race experience should show:

- the pick
- the confidence boundary
- the signal stack
- the risk warnings
- the evidence status
- the post-race truth

The app is the public-facing Verification Interface of ETCSLV.

---

## ETCSLV Product Framing

### Execution Loop in product terms

Today's races -> VELO score -> Signal Stack -> operator/user view -> post-race audit -> evidence refresh

### Tool Registry in product terms

The product must expose trusted tools, not hide them:

- VP
- Tier
- MDS
- improvement score
- place probability
- candidate lanes
- router lane status

### Context Manager in product terms

Users should see race context, not isolated picks:

- venue and time
- going
- class
- distance
- archetype/context notes when relevant

### State Store in product terms

Every view must be backed by stored evidence:

- daily verdicts
- special-day reports
- signal rankings
- router evidence
- candidate-lane evidence

### Life Cycle Hooks in product terms

The UI should reflect whether a signal is:

- shadow-only
- watchlist
- candidate
- promoted
- suppressed
- forensics-only

### Verification Interface in product terms

Users should be able to inspect:

- post-race audits
- live evidence rankings
- special-day reports
- router evidence snapshots
- candidate-lane truth

---

## Pages

### 1. Home / Today

- today's race schedule
- VELO's top pick by race
- VP and tier
- visible Signal Stack badges
- "shadow evidence only" status when applicable
- quick prior-day audit summary

### 2. Daily Intelligence Feed

For each race:

- venue + time
- top pick
- VP
- decision tier
- active signal badges
- sidecar values
- risk warnings
- evidence line for each active badge
- post-race update after closure

### 3. Historical Performance Dashboard

- VP band performance
- tier performance
- candidate-lane performance
- router lane performance
- frame and strike trends
- signal ranking history

### 4. Signal Intelligence

- glossary of VP, tier, MDS, improvement, place probability
- what VP30 means
- what MDS_HIGH means
- what B_LOW_VP_SUPPRESS means
- why mid-price zone is a risk watch

### 5. Post-Race Audit

- race-by-race prediction versus result
- miss classes
- why the system missed
- whether risk flags were present

### 6. Evidence Vault

- latest evidence reports
- special-day reports
- Router Evidence Engine status
- candidate-lane status
- ETCSLV architecture summary

### 7. About

- VELO company story
- ETCSLV architecture in plain English
- what VELO is and is not
- responsible-use language

---

## Signal Stack Surface

The MVP should display this structure on each eligible race:

- `Pick`
- `VP`
- `Tier`
- active badges:
  - VP30_TIER_A
  - MDS_HIGH
  - IMPROVE_HIGH
  - PLACE_PROB_HIGH
- risk flags:
  - B_LOW_VP_SUPPRESS
  - VP_020_030_DRAG
  - MID_PRICE_ZONE_WATCH
- status:
  - SHADOW EVIDENCE ONLY
  - WATCHLIST
  - SHADOW_CANDIDATE
  - SUPPRESS_CANDIDATE
  - FORENSICS_ONLY

---

## Confidence Boundary Display

| Boundary | Evidence |
|---|---|
| VP < 0.20 | 14.5% SR / 33.5% frame |
| VP 0.20-0.30 | 18.0% SR / 47.8% frame |
| VP 0.30-0.40 | 27.3% SR / 62.9% frame |
| VP >= 0.40 | 44.0% SR / 85.0% frame |
| VP30_TIER_A | 40.1% SR / 77.2% frame |

This is the product language of trust.

---

## What The MVP Must Not Do

- no staking automation
- no live bet execution
- no hidden signal logic
- no unexplained picks
- no public claim beyond evidence

---

## Legal Framing

VELO provides race intelligence for informational and analytical purposes only. It does not constitute betting advice. Past performance does not guarantee future results. Signals may be shadow-only, under sample, or forensics-only.

---

*VELO Website / App MVP Spec V1 | Updated 2026-04-29 for ETCSLV alignment*
