# VELO Company Master Plan V1

**Date:** 2026-04-29  
**Status:** Evidence-grounded roadmap aligned to ETCSLV  
**Positioning:** Auditable racing intelligence operating system, not a tipster, not a gambling bot

---

## The Thesis

Horse racing intelligence is crowded with picks and empty of proof. VELO is building the opposite: an operating system that scores races, records what it said, audits what happened, ranks which internal signals deserve trust, and exposes that truth to the human operator.

The product is not "a horse pick."  
The product is an auditable decision loop.

---

## ETCSLV Doctrine

VELO now adopts ETCSLV as its operating architecture:

1. **Execution Loop**  
   Pre-race scoring, product routing, Telegram delivery, and post-race reconciliation.
2. **Tool Registry**  
   The model stack, sidecar signals, signal glossary, router lanes, candidate lanes, and signal badges.
3. **Context Manager**  
   Racecards, course/going/class context, macro regime, archetypes, and operator-day context.
4. **State Store**  
   Supabase live tables plus Git evidence artifacts, state JSON, and append-only ledgers.
5. **Life Cycle Hooks**  
   Pre-race render hooks, post-race sigma hooks, special-day hooks, router threshold hooks, and candidate-lane promotion hooks.
6. **Verification Interface**  
   Sigma audits, Router Evidence Engine, Evidence Vault, Signal Stack, special-day reports, and the Operating Truth Board.

ETCSLV is the architecture.  
Evidence Vault is the memory.  
Telegram Signal Stack is the operator interface.  
Router and sigma are the verification layer.  
Candidate lanes are lifecycle-controlled promotion paths.

---

## Where We Are Now

### First Era: Build VELO

The first era produced the intelligence engine:

- VeloPrimeEnsemble live scorer
- SQPE plus specialist sidecars
- Daily sigma reconciliation
- Unified evidence audits
- Router shadow evidence engine
- Evidence Vault

### Second Era: Make VELO Legible

The second era makes the system investable and commercially credible:

- VP lineage audited in repo
- Telegram visibility audited in repo
- Signal discovery report created
- Signal Stack display patch shipped locally
- Candidate-lane governance designed
- Company narrative aligned to ETCSLV

This is the transition from "interesting model" to "auditable intelligence company."

---

## What We Have Today

- 49 live operating days
- 1,391 sigma-audited rows
- 1,604 verdicts in live evidence scope
- Router Evidence Engine running in shadow
- Evidence Vault initialized and active
- Signal Stack visible through display-only Telegram patch
- Zero live staking
- Zero router promotion
- Playbook G still offline-research-only

### Current core discoveries

- **VP30_TIER_A**: 40.1% SR, 77.2% frame, n=162
- **MDS_HIGH**: 54.8% SR, 96.8% frame, n=31
- **IMPROVE_HIGH**: 43.5% SR, 82.3% frame, n=62
- **PLACE_PROB_HIGH**: 31.6% SR, 66.8% frame, n=392
- **B_LOW_VP_SUPPRESS**: 16.9% SR, 44.1% frame, n=272
- **MID_PRICE_ZONE_WATCH**: SP 3.0-8.5 zone drives 58% of all misses

---

## Strategic Meaning

VELO does not just predict horses. It now shows:

- what it picked
- how confident it was
- which proven signal families fired
- what risk flags apply
- what remains shadow-only
- what is not yet promotion-safe

That is the basis for a defensible company story.

---

## Phase 1: Evidence Readiness

**Goal:** Build investor-grade, auditable evidence package from live data.

Deliverables:

- [ ] Unified Evidence Audit V2
- [ ] Candidate-lane shadow ledger dry run
- [ ] Daily lane accumulation against closed results
- [ ] Router V2 reaches WATCHLIST gate
- [ ] Operating Truth Board refreshed with 60+ day evidence
- [ ] Audit dossier connecting input -> verdict -> result -> lesson

---

## Phase 2: Operator Product Core

**Goal:** Turn hidden model intelligence into visible operator intelligence.

Core modules:

1. Daily race intelligence feed
2. Signal Stack with evidence lines
3. Sidecar proof layer
4. Risk-warning layer
5. Router lane status
6. Candidate-lane status
7. Post-race audit
8. Historical truth dashboard

This phase is about legibility, not more model complexity.

---

## Phase 3: Website / App MVP

**Goal:** Public-facing intelligence platform that exposes ETCSLV cleanly.

Public product must show:

- the pick
- VP and tier
- signal stack
- historical confidence performance
- post-race reconciliation
- evidence-backed risk flags
- shadow-only / promoted status labels

The user-facing product is evidence plus explanation, not blind picks.

---

## Phase 4: Whitepaper

**Goal:** Publish VELO as an auditable intelligence architecture.

Whitepaper must explain:

- the racing-intelligence problem
- ETCSLV as VELO operating architecture
- the live evidence methodology
- the signal-compression discoveries
- current governance controls
- current blockers
- commercial applications

---

## Phase 5: Business Plan

**Goal:** Translate the architecture into products and revenue paths.

Company pillars:

1. Consumer intelligence app
2. Pro analytics dashboard
3. Data/API product
4. Stable/trainer/owner intelligence tools
5. Media/content layer
6. Enterprise licensing

The moat is not just model quality. The moat is verifiable intelligence operations.

---

## Phase 6: Funding Pack

**Goal:** Present VELO as a category-defining operating system, not a betting gimmick.

Funding story:

> VELO is an auditable racing intelligence operating system built on ETCSLV. It does not just score races. It executes, records, audits, learns, verifies, and explains its own confidence. The company has already identified multiple live signal families with measurable lift, built immutable evidence storage, and exposed the operator-visibility gap that separates model intelligence from usable intelligence.

---

## Phase 7: Controlled Release

**No public release until:**

- candidate-lane shadow ledger is live and stable
- router and candidate promotions are evidence-backed
- operator interface is trusted
- legal/compliance review is complete
- evidence package is publication-ready
- no staking automation is enabled

Release format: open evidence, clear risk flags, governed language, no overclaiming.

---

## Permanent Rules

- No live staking until explicit release decision
- No router promotion without ledger evidence
- No model promotion without audit evidence
- No market recrowding inside the core learner
- No public claims beyond what the evidence proves
- No responsible-gambling shortcuts

---

## The Story We Tell

**First era:** build VELO.  
**Second era:** make VELO legible, auditable, and commercially credible.

That is now the master plan.

---

*VELO Company Master Plan V1 | Updated 2026-04-29 for ETCSLV alignment*
