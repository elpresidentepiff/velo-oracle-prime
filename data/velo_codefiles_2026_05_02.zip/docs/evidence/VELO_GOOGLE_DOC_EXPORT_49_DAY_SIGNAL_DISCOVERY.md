# VELO 49-Day Signal Discovery Report - Google Doc Export

## Executive Summary

VELO is no longer just producing predictions. It is discovering which internal confidence structures are genuinely trustworthy.

Key findings:

- Global 49-day SR = 20.6%
- Global 49-day frame = 48.4%
- VP30_TIER_A = 40.1% SR / 77.2% frame / n=162
- MDS_HIGH = 54.8% SR / 96.8% frame / n=31
- IMPROVE_HIGH = 43.5% SR / 82.3% frame / n=62
- B_LOW_VP_SUPPRESS = 16.9% SR / 44.1% frame / n=272
- SP 3.0-8.5 zone = 58% of all misses

## What This Means

VELO has crossed from engine-building into legibility and governance.

It is no longer enough to know the pick. The operator must also see:

- why the pick is strong
- which signal families fired
- which risk flags apply
- whether the evidence is still shadow-only

## VP30 Definition

- VP = `velo_prime_prob`
- VP30 = `velo_prime_prob >= 0.30`
- VP30_TIER_A = `velo_prime_prob >= 0.30 AND decision_tier == 'A'`

## VP Monotonicity

| Band | n | SR | Frame |
|---|---:|---:|---:|
| VP < 0.20 | 385 | 14.5% | 33.5% |
| VP 0.20-0.30 | 460 | 18.0% | 47.8% |
| VP 0.30-0.40 | 245 | 27.3% | 62.9% |
| VP >= 0.40 | 100 | 44.0% | 85.0% |

## Signal Compression Discoveries

- VP30_TIER_A: broad proven trust boundary
- MDS_HIGH: strongest hidden sidecar signal
- IMPROVE_HIGH: strong underused signal
- PLACE_PROB_HIGH: large-sample helpful signal
- B_LOW_VP_SUPPRESS: confirmed warning zone
- MID_PRICE_ZONE_WATCH: main miss battlefield

## Operator Layer Truth

Before the display patch, Telegram did not surface the full badge stack.  
After the display-only patch, the operator can see the Signal Stack if the patched sender is used.

## Why This Is Not A Deployment Claim

- no model change
- no router change
- no staking
- no promotion

This is a visibility and auditability upgrade.

## ETCSLV Meaning

This report feeds the ETCSLV system in four ways:

- it updates the **Tool Registry**
- it strengthens the **State Store**
- it informs future **Life Cycle Hooks**
- it improves the **Verification Interface**

## Company Meaning

First era: build VELO.  
Second era: make VELO legible, auditable, and commercially credible.

That is the company shift this report captures.

---

*VELO Google Doc Export - 49-Day Signal Discovery*
